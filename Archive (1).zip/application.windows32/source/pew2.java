import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class pew2 extends PApplet {

RedBall ball1 = new RedBall(100, 500, 50);//x, y, s
swish swish1 = new swish(); 
swishA swishA1 = new swishA(); 
level level1 = new level();
score score1 = new score();

boolean pewHit=false;
boolean pew = false;//is there a pew out there
boolean pewHitted;
boolean pewMove=true;
float LeftorRight;
float vSwish=0.05f;//speed of swish
int counter=0;//count the score
int level=1;
boolean swishHit=false;
boolean swish=true;
float ySwish=random (200);
float xSwishLeft=0;
float xSwishRight=500;
float xSwish;
boolean swish2Hit=false;
boolean swish2=true;
float LeftorRight2;
float ySwish2=random(200);
float xSwish2Left=0;
float xSwish2Right=500;
float xSwish2;
int yPos = 500;
int xPos;
int xPew;
float yDisp=1;
float yPew;
PFont f;
PFont z;


public void setup()
{
  size(500, 500);
  frameRate(1000);
}

public void draw()
{  
  ball1.update();
  swish1.oncePerSwish();
  swish1.leftRight();
  swishA1.oncePerSwish2();
  swishA1.leftRight2();
  ball1.pew();
  ball1.pewDraw();
  ball1.yPosition();
  score1.scoreUp();
  score1.printText();
  score1.loser();
  level1.levelUp();
}

public void mousePressed()
{
  ball1.makePew();
}

public void keyPressed() {
  if (key == ' ') {
    ball1.makePew();
  }
}

class level {
  public void levelUp() {
    if (counter==level*10)
    {
      if (level<=2)
      {
        vSwish=vSwish*level;
        yDisp=yDisp+(0.1f*level);
        level++;
      }
      else
      {
        vSwish=vSwish+0.01f;
        yDisp=yDisp+0.01f;
        level++;
      }
    }
  }
}

class score {
  public void scoreUp() {
    if ((xSwish<xPew+6)&&(xSwish+20>=xPew)&&(ySwish<yPew+6)&&(ySwish+20>yPew))
    {
      counter++;
      reset1();
    }
    if ((xSwish2<xPew+6)&&(xSwish2+20>=xPew)&&(ySwish2<yPew+6)&&(ySwish2+20>yPew))
    {
      counter++;
      reset2();
    }
  }

  public void reset1() {
    ySwish=random (400);
    pewHit=false;
    swishHit=true;
    pew=false;
    pewHitted = false;
    pewMove=true;
  }

  public void reset2() {
    ySwish2=random (400);
    pewHit=false;
    swish2Hit=true;
    pew=false;
    pewHitted = false;
    pewMove=true;
  }
  public void printText() {
    f=createFont("Arial", 16, true);
    textFont(f, 15);
    fill(123);
    rect(20, 40, 0, 0);
    fill(0);
    textAlign(LEFT);
    text("Score: "+counter, 5, 20);
    text("Level: "+level, 5, 40);
  }

  public void loser() {
    if ((xSwishLeft>510)||(xSwishRight<-10)||(xSwish2Left>510)||(xSwish2Right<-10))
    {
      background(255);
      z = createFont("Arial", 16, true);
      textFont(z, 70);
      textAlign(CENTER);
      text("Game Over", 250, 250);
      printText();
    }
  }
}

class swish {
  public void oncePerSwish() {
    if (swish==true) 
    {
      LeftorRight=random(1);
      swish=false;
    }
    if (swishHit==true)
    {
      swishHit=false;
      swish=true;
      xSwishLeft=0;
      xSwishRight=500;
    }
  }

  public void leftRight() {
    if (LeftorRight>=0.5f) 
    {
      if ((xSwishLeft<510)&&(swishHit==false)) 
      {
        rect(xSwishLeft, ySwish, 20, 10);
        xSwishLeft=xSwishLeft+vSwish;
        xSwish=xSwishLeft;
      }
    }
    else if (LeftorRight<0.5f) 
    {
      if ((xSwishRight>-10)&&(swishHit==false)) 
      {
        rect(xSwishRight, ySwish, 20, 10);
        xSwishRight=xSwishRight-vSwish;
        xSwish=xSwishRight;
      }
    }
  }
}

class swishA {
  public void oncePerSwish2() {
    if (swish2==true) 
    {
      LeftorRight2=random(1);
      swish2=false;
    }
    if (swish2Hit==true)
    {
      swish2Hit=false;
      swish2=true;
      xSwish2Left=0;
      xSwish2Right=500;
    }
  }

  public void leftRight2() {
    if (LeftorRight2>=0.5f) 
    {
      if ((xSwish2Left<510)&&(swish2Hit==false)) 
      {
        fill(255, 255, 0);
        rect(xSwish2Left, ySwish2, 20, 10);
        xSwish2Left=xSwish2Left+vSwish;
        xSwish2=xSwish2Left;
      }
    }
    else if (LeftorRight2<0.5f) 
    {
      if ((xSwish2Right>-10)&&(swish2Hit==false)) 
      {
        fill(255, 255, 0);
        rect(xSwish2Right, ySwish2, 20, 10);
        xSwish2Right=xSwish2Right-vSwish;
        xSwish2=xSwish2Right;
      }
    }
  }
}

interface Ball {
  public void update();
  // void xtemp();
}

class RedBall {
  float size;
  RedBall (int x, int y, float s) {
    xPos = x;
    yPos = y;
    size = s;
  }

  public void makePew()
  {
    pew = true;
  }

  public void update() {
    xPos = mouseX;
    background(255);
    fill(255, 0, 0);
    ellipse(xPos, yPos, size, size);
  }

  public void pew() {
    if ((pew==true)&&(pewMove==true)) 
    {
      xPew=mouseX-3;//centers the pew
      yPew=475;
      pewMove=false;
    }
  }

  public void pewDraw() {
    if (pewMove==false)
    {
      fill(255, 0, 0);
      rect(xPew, yPew, 6, 6);
    }
  }

  public void yPosition() {
    if ((pew==true)&&(pewHitted==false)&&(pewHit==false))
    {
      yPew=yPew-yDisp;
      if (yPew<0)
      {
        pew=false;
        pewMove=true;
      }
    }
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "pew2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
